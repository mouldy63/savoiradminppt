<?php

//$ratestype is passed in as a parameter. 0=display internal view of rates, 1=display external view of rates
//set to TEST
//$ratestype = 1;

$rateid_array = $ratebands->getRateidArray();
$description_array = $ratebands->getDescriptionArray();
$start_array = $ratebands->getStartArray();
$end_array = $ratebands->getEndArray();
$weekly_array = $ratebands->getWeeklyArray();
$nightly_array = $ratebands->getNightlyArray();
$weekend_array = $ratebands->getWeekendArray();
$monthly_array = $ratebands->getMonthlyArray();
$minstay_array = $ratebands->getMinstayArray();

$basecurrency = $ratesinfo->getBasecurrency();
$deposit = $ratesinfo->getDeposit();
$cleaning = $ratesinfo->getCleaning();
$taxrate = $ratesinfo->getTaxrate();
$additionalnotes = $ratesinfo->getAdditionalnotes();
$cancellation = $ratesinfo->getCancellation();

if ($ratestype == 1) {
	//convert basecurrency flag to currency code
	if ($basecurrency == 'D') {$basecurrencycode = 'USD';}
	if ($basecurrency == 'S') {$basecurrencycode = 'GBP';}
	if ($basecurrency == 'E') {$basecurrencycode = 'EUR';}

	print "<p>These rates were set in <b>".$basecurrencycode."</b></p>";

} else {
	print "<h1>Manage Rates</h1>";
}

//display gaps in rates if there are rate bands added (if for internal display)
if ($ratestype == 0) {
if (count($rateid_array) > 0) {
if (count($ratebands->getRatesGaps()) > 0) {
	print "<p><div class='alert alert-info' role='alert'>You have a gap in your rate bands after the following dates: ";
	$counter = 0;
	$rategaps_array = $ratebands->getRatesGaps();
	foreach ($rategaps_array as &$value) {
		if ($counter > 0) {print ", ";}
		print $view->getDayMonthYearfromDate($value);
		$counter=$counter+1;
	}
	unset($value); // break the reference with the last element
	print "</div></p>";
}
}
}


//create new div holder for each results line
if ($ratestype == 0) {print "<div id='ratestable-internal'>";} else {print "<div id='ratestable-external'>";}
print "<div class='table-responsive'><table class='table table-striped'>";

print "</tr>";
print "<th>Rate Period</th><th>Nightly*</th><th>Weekly*</th><th>Weekend*</th><th>Monthly*</th><th>Min Stay</th>";
if ($ratestype == 0) {print "<th><form method='post'>
<label for='currencyselect'>Display rates in: </label>
<select class='form-control' name='currencyselect' id='currencyselect' onchange='removeCurrencies(this);'  style='width:117px;'>
<option value='D'";
if ($basecurrency == 'D') {print "SELECTED";}
print ">USD</option><option value='S'";
if ($basecurrency == 'S') {print "SELECTED";}
print ">GBP</option><option value='E'";
if ($basecurrency == 'E') {print "SELECTED";}
print ">EUR</option>
</select>
</form></th>";
print "<script type='text/javascript'>
function removeCurrencies(elem) {
$('.dollars').hide();
$('.sterling').hide();
$('.euros').hide();

if(elem.value == 'D') {
$('.dollars').show();
}
if(elem.value == 'S') {
$('.sterling').show();
}
if(elem.value == 'E') {
$('.euros').show();
}
}</script>";
}
print "</tr>";
$counter = 0;

foreach ($rateid_array as &$value) {
	//if ($counter % 2 == 0) {
	//print "<tr style='background: #F5FAFA;'>"; 
	//} else {
	print "<tr>"; 
	//}
	
	print "<td>".$description_array[$counter]."<br>".$view->getDayMonthYearfromDate($start_array[$counter])." - ".$view->getDayMonthYearfromDate($end_array[$counter])."</th><td>";

	if ($nightly_array[$counter]) {
		if ($ratestype == 0) {
			switch ($basecurrency) {
				case 'S':
					$gbp = number_format($nightly_array[$counter]);
					$usd = number_format($nightly_array[$counter] * $exchangerates->getGBPUSD());
					$eur = number_format($nightly_array[$counter] * $exchangerates->getGBPEUR());
					print "<div class='sterling'>".$view->formatCurrency($basecurrency).$gbp."</div>";
					print "<div class='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div class='euros' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'D':
					$usd = number_format($nightly_array[$counter]);
					$gbp = number_format($nightly_array[$counter] * $exchangerates->getUSDGBP());
					$eur = number_format($nightly_array[$counter] * $exchangerates->getUSDEUR());
					print "<div class='dollars'>".$view->formatCurrency($basecurrency).$usd."</div>";
					print "<div class='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					print "<div class='euros' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'E':
					$eur = number_format($nightly_array[$counter]);
					$usd = number_format($nightly_array[$counter] * $exchangerates->getEURUSD());
					$gbp = number_format($nightly_array[$counter] * $exchangerates->getEURGBP());
					print "<div class='euros'>".$view->formatCurrency($basecurrency).$eur."</div>";
					print "<div class='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div class='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					break;
			}
		} else {
			switch ($basecurrency) {
				case 'S':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency($basecurrency).number_format($nightly_array[$counter]);
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($nightly_array[$counter] * $exchangerates->getGBPUSD());
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($nightly_array[$counter] * $exchangerates->getGBPEUR());
						break;
					}
					break;
				case 'D':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($nightly_array[$counter] * $exchangerates->getUSDGBP());
						break;
					case 'US':
						print $view->formatCurrency($basecurrency).number_format($nightly_array[$counter]);
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($nightly_array[$counter] * $exchangerates->getUSDEUR());
						break;
					}
					break;
				case 'E':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($nightly_array[$counter] * $exchangerates->getEURGBP());
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($nightly_array[$counter] * $exchangerates->getEURUSD());
						break;
					case 'EU':
						print $view->formatCurrency($basecurrency).number_format($nightly_array[$counter]);
						break;
					}
					break;
			}
		}
	} else {
		print "-";

	}
	print "</td><td>";

	if ($weekly_array[$counter]) {
		if ($ratestype == 0) {
			switch ($basecurrency) {
				case 'S':
					$gbp = number_format($weekly_array[$counter]);
					$usd = number_format($weekly_array[$counter] * $exchangerates->getGBPUSD());
					$eur = number_format($weekly_array[$counter] * $exchangerates->getGBPEUR());
					print "<div class='sterling'>".$view->formatCurrency($basecurrency).$gbp."</div>";
					print "<div class='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div class='euros' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'D':
					$usd = number_format($weekly_array[$counter]);
					$gbp = number_format($weekly_array[$counter] * $exchangerates->getUSDGBP());
					$eur = number_format($weekly_array[$counter] * $exchangerates->getUSDEUR());
					print "<div class='dollars'>".$view->formatCurrency($basecurrency).$usd."</div>";
					print "<div class='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					print "<div class='euros' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'E':
					$eur = number_format($weekly_array[$counter]);
					$usd = number_format($weekly_array[$counter] * $exchangerates->getEURUSD());
					$gbp = number_format($weekly_array[$counter] * $exchangerates->getEURGBP());
					print "<div class='euros'>".$view->formatCurrency($basecurrency).$eur."</div>";
					print "<div class='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div class='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					break;
			}
		} else {
			switch ($basecurrency) {
				case 'S':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency($basecurrency).number_format($weekly_array[$counter]);
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($weekly_array[$counter] * $exchangerates->getGBPUSD());
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($weekly_array[$counter] * $exchangerates->getGBPEUR());
						break;
					}
					break;
				case 'D':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($weekly_array[$counter] * $exchangerates->getUSDGBP());
						break;
					case 'US':
						print $view->formatCurrency($basecurrency).number_format($weekly_array[$counter]);
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($weekly_array[$counter] * $exchangerates->getUSDEUR());
						break;
					}
					break;
				case 'E':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($weekly_array[$counter] * $exchangerates->getEURGBP());
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($weekly_array[$counter] * $exchangerates->getEURUSD());
						break;
					case 'EU':
						print $view->formatCurrency($basecurrency).number_format($weekly_array[$counter]);
						break;
					}
					break;
			}
		}
	} else {
		print "-";
	}
	print "</td><td>";

	if ($weekend_array[$counter]) {
		if ($ratestype == 0) {
			switch ($basecurrency) {
				case 'S':
					$gbp = number_format($weekend_array[$counter]);
					$usd = number_format($weekend_array[$counter] * $exchangerates->getGBPUSD());
					$eur = number_format($weekend_array[$counter] * $exchangerates->getGBPEUR());
					print "<div id='sterling'>".$view->formatCurrency($basecurrency).$gbp."</div>";
					print "<div id='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div id='euro' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'D':
					$usd = number_format($weekend_array[$counter]);
					$gbp = number_format($weekend_array[$counter] * $exchangerates->getUSDGBP());
					$eur = number_format($weekend_array[$counter] * $exchangerates->getUSDEUR());
					print "<div id='dollars'>".$view->formatCurrency($basecurrency).$usd."</div>";
					print "<div id='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					print "<div id='euro' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'E':
					$eur = number_format($weekend_array[$counter]);
					$usd = number_format($weekend_array[$counter] * $exchangerates->getEURUSD());
					$gbp = number_format($weekend_array[$counter] * $exchangerates->getEURGBP());
					print "<div id='euro'>".$view->formatCurrency($basecurrency).$eur."</div>";
					print "<div id='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div id='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					break;
			}
		} else {
			switch ($basecurrency) {
				case 'S':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency($basecurrency).number_format($weekend_array[$counter]);
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($weekend_array[$counter] * $exchangerates->getGBPUSD());
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($weekend_array[$counter] * $exchangerates->getGBPEUR());
						break;
					}
					break;
				case 'D':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($weekend_array[$counter] * $exchangerates->getUSDGBP());
						break;
					case 'US':
						print $view->formatCurrency($basecurrency).number_format($weekend_array[$counter]);
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($weekend_array[$counter] * $exchangerates->getUSDEUR());
						break;
					}
					break;
				case 'E':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($weekend_array[$counter] * $exchangerates->getEURGBP());
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($weekend_array[$counter] * $exchangerates->getEURUSD());
						break;
					case 'EU':
						print $view->formatCurrency($basecurrency).number_format($weekend_array[$counter]);
						break;
					}
					break;
			}
		}
	} else {
		print "-";
	}
	print "</td><td>";

	if ($monthly_array[$counter]) {
		if ($ratestype == 0) {
			switch ($basecurrency) {
				case 'S':
					$gbp = number_format($monthly_array[$counter]);
					$usd = number_format($monthly_array[$counter] * $exchangerates->getGBPUSD());
					$eur = number_format($monthly_array[$counter] * $exchangerates->getGBPEUR());
					print "<div id='sterling'>".$view->formatCurrency($basecurrency).$gbp."</div>";
					print "<div id='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div id='euro' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'D':
					$usd = number_format($monthly_array[$counter]);
					$gbp = number_format($monthly_array[$counter] * $exchangerates->getUSDGBP());
					$eur = number_format($monthly_array[$counter] * $exchangerates->getUSDEUR());
					print "<div id='dollars'>".$view->formatCurrency($basecurrency).$usd."</div>";
					print "<div id='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					print "<div id='euro' style='display: none;'>".$view->formatCurrency('E').$eur."</div>";
					break;
				case 'E':
					$eur = number_format($monthly_array[$counter]);
					$usd = number_format($monthly_array[$counter] * $exchangerates->getEURUSD());
					$gbp = number_format($monthly_array[$counter] * $exchangerates->getEURGBP());
					print "<div id='euro'>".$view->formatCurrency($basecurrency).$eur."</div>";
					print "<div id='dollars' style='display: none;'>".$view->formatCurrency('D').$usd."</div>";
					print "<div id='sterling' style='display: none;'>".$view->formatCurrency('S').$gbp."</div>";
					break;
			}
		} else {
			switch ($basecurrency) {
				case 'S':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency($basecurrency).number_format($monthly_array[$counter]);
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($monthly_array[$counter] * $exchangerates->getGBPUSD());
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($monthly_array[$counter] * $exchangerates->getGBPEUR());
						break;
					}
					break;
				case 'D':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($monthly_array[$counter] * $exchangerates->getUSDGBP());
						break;
					case 'US':
						print $view->formatCurrency($basecurrency).number_format($monthly_array[$counter]);
						break;
					case 'EU':
						print $view->formatCurrency('E').number_format($monthly_array[$counter] * $exchangerates->getUSDEUR());
						break;
					}
					break;
				case 'E':
					switch ($view->getUserContext()) {
					case 'UK':
						print $view->formatCurrency('S').number_format($monthly_array[$counter] * $exchangerates->getEURGBP());
						break;
					case 'US':
						print $view->formatCurrency('D').number_format($monthly_array[$counter] * $exchangerates->getEURUSD());
						break;
					case 'EU':
						print $view->formatCurrency($basecurrency).number_format($monthly_array[$counter]);
						break;
					}
					break;
			}
		}
	} else {
		print "-";
	}
	print "</td><td>";

	if ($minstay_array[$counter]) {print $minstay_array[$counter]." Nights";} else {print "-";}
	print "</td>";
	//if ($ratestype == 0) {print "<td style='width:110px;'><a href='/user/managerates/?cmd=LoginDisplayRate&rateid=".$rateid_array[$counter]."' class='btn btn-sm btn-success ' style='width:40px;'>edit</a>&nbsp;<a href='/user/managerates/?cmd=LoginDeleteRate&rateid=".$rateid_array[$counter]."' class='btn btn-sm btn-danger' style='width:40px;'>delete</a></td>";}
	if ($ratestype == 0) {print "<td><a href='/user/managerates/?cmd=LoginDisplayRate&rateid=".$rateid_array[$counter]."' class='btn btn-sm btn-success '>edit</a>&nbsp;<a href='/user/managerates/?cmd=LoginDeleteRate&rateid=".$rateid_array[$counter]."' class='btn btn-sm btn-danger'>delete</a></td>";}
	print "</tr>";

	$counter = $counter +1;
}

unset($value); // break the reference with the last element

//if no rates to present add placeholder no rates to display message (cater for internal and external display where there are varying colspan requirements)
if ($counter == 0) {
if ($ratestype == 0) {print "<tr><td colspan='7'>There are currently no rate bands to display<td></tr>";}
if ($ratestype == 1) {print "<tr><td colspan='6'>There are currently no rate bands to display<td></tr>";}
}

print "</table></div>";
print "</div>";

print "<p><b>Deposit: </b>".$deposit."</p>";
print "<p><b>Cleaning: </b>".$cleaning."</p>";
print "<p><b>Tax Rate: </b>".$taxrate."</p>";
print "<p><b>Cancellation: </b>".$cancellation."</p>";
print "<p><b>Additional Notes: </b>".$additionalnotes."</p>";

print "* All rates are indicative and can be subject to currency fluctuations and party size. We commit that all rates when quoted in base currency will be within a 10% tolerance of those displayed.";

if ($ratestype == 0) {

print "<div class='row'><div class='col-sm-12 about-us-text'></div></div>";

	print "<div class='row'><div class='col-sm-12 about-us-text'><h3>Guidance</h3><p>Set the currency you are storing the rates in below in the Additional Rate Info form.  Rates are stored in a base currency but can be displayed in USD, GBP and EUR dependent on holidaymaker preference and location.  Exchange rates are set daily from Yahoo Finance and are currently: USDGBP ".$exchangerates->getUSDGBP().", USDEUR ".$exchangerates->getUSDEUR().", GBPUSD ".$exchangerates->getGBPUSD().", GBPEUR ".$exchangerates->getGBPEUR().", EURUSD ".$exchangerates->getEURUSD().", EURGBP ".$exchangerates->getEURGBP()."</p></div></div>";
	print "<div class='row'><div class='col-sm-12 about-us-text'><h3>Terms & Conditions:</h3><p>Rates displayed must be within 10% of the rates quoted to holidaymakers.  Setting falsely low rates which are not then offered is a breach of terms and will result in your property being delisted.</p></div></div>";

}

?>