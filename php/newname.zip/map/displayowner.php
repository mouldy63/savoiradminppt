<?php

//display owner details
print "<h3>Owner Information</h3>";
print "<p><strong>Owner:</strong> ".$propertydetails->getOwner()."</p>";
print "<p><strong>Management Company:</strong> ".$propertydetails->getAgent()."</p>";
print "<p><strong>Local Phone:</strong> ".$propertydetails->getLocalphone()."</p>";
print "<p><strong>International Phone:</strong> ".$propertydetails->getIntphone()."</p>";
if ($view->getOwnerWebsites()) {
	if ($propertydetails->getWebsite()) {
		print "<p><a rel='nofollow' href='".$propertydetails->getWebsite()."'  target='_blank'><button type='button' class='btn btn-primary'>Website</button></a></p>";
	}
}

?>