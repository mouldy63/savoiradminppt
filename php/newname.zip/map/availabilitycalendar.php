<?php

$html_out = "";

print "<div id='availabilitycalendar'>";

$prevslot=0; //store previous booking state

	if ($calendartype==0) {

	print "<h2>Manage Availability</h2>";

	print "<div class='alert alert-info' role='alert'><i class='fa fa-lightbulb-o'></i> To edit bookings simply click on the relevant dates in the calendar and then update using the UPDATE BOOKING form.</div>";
	
	$months_to_show = 36;			//TODO: change to the number of months you'd like to show
	
	} else {
	
	print "<h3>Availability Calendar</h3>";
	
	$months_to_show = 24;			//TODO: change to the number of months you'd like to show
	
	}
		
	for ($m = 0; $m < $months_to_show; $m++) {
		$month = $this_month + $m;
		if ($month > 12) {
			$show_month = $month % 12;
			if ($show_month == 0)
			$show_month = 12;
			$show_year = $this_year + ($month - $show_month) / 12;
		}
		else {
			$show_month = $month;
			$show_year = $this_year;
		}
		// option 1, if would like to be able to add other languages in a future
		//$month_names = array(1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
		//$html_out .= "<div class=\"calendar\"><strong>{$month_names['$show_month']} $show_year</strong><br />";
		//option 2, uses PHP to get the name:
		$monthName = date("F", mktime(0, 0, 0, $show_month, 10));
		$html_out .= "<div class=\"calendar\"><strong>$monthName $show_year</strong>";
		
		
		$arraydow = array("M", "T", "W", "T", "F", "S", "S");
		
		for($i = $dowoffset; $i <= 6; $i++)	{
			    $html_out .= "<span class='dow'>".$arraydow[$i]."</span>";
			}
		for($i = 0; $i < $dowoffset; $i++)	{
			    $html_out .= "<span class='dow'>".$arraydow[$i]."</span>";
			}
		
		$html_out .= "<br>";
		
		$date = strtotime("$show_year-$show_month-01");
		
		$dw = date("N", $date);
		$dw = $dw - $dowoffset;
		//if ($dw==0) {
		//$dw=7;
		//}

		if ($dw==0) { $dw=7; }
		if ($dw==-6) { $dw=1; }
		if ($dw==-5) { $dw=2; }
		if ($dw==-4) { $dw=3; }
		if ($dw==-3) { $dw=4; }
		if ($dw==-2) { $dw=5; }
		if ($dw==-1) { $dw=6; }

		
		for ($i = 1; $i < $dw; $i++)
		
			$html_out .= '<span>&nbsp;</span>';	//align days in calendar (necessary when day 1 isn't monday)
		$day = 0;
		if (!isset($availabilitycalendar->reservations[$show_year.sprintf("%02d", $show_month)])) {	//no more reservations
			$days_in_month = cal_days_in_month(CAL_GREGORIAN, $show_month, $show_year);
			for ($d = 1; $d <= $days_in_month; $d++) {
				$day++;
				$dw++;
				$html_out .= "<span>$day</span>";
				if ($dw > 7) {
					$html_out .= '<br />';
					$dw = 1;
				}
			}
		}
		else foreach ($availabilitycalendar->reservations[$show_year.sprintf("%02d", $show_month)] as $booked) {	//foreach Day in YearMonth
			$day++;
			$dw++;
			if ($booked == 0)
				if ($prevslot == 1) {
				$html_out .= "<span class=\"bookedcheckout\">$day</span>";
				$prevslot =0;
				} else {
				$html_out .= "<span>$day</span>";	//available
				}
			
				
			else
			
if ($prevslot == 0) {

if ($calendartype==0) {
			$html_out .= "<a class='bookedcheckin tooltip' 
title= 'Guest: {$availabilitycalendar->bookings[$booked]['guest']}
Checkin date: {$availabilitycalendar->bookings[$booked]['checkin']}
Checkout date: {$availabilitycalendar->bookings[$booked]['checkout']}
Price: {$availabilitycalendar->bookings[$booked]['price']}
Comments: {$availabilitycalendar->bookings[$booked]['comments']}' href='managebookings.php?cmd=LoginDisplayBooking&bookingid=$booked'>$day</a>";

} else {
$html_out .= "<span class=\"bookedcheckin\">$day</span>";
}
			$prevslot =1;
			} else {
			if ($calendartype==0) {
			$html_out .= "<a class='booked tooltip' 
title= 'Guest: {$availabilitycalendar->bookings[$booked]['guest']}
Checkin date: {$availabilitycalendar->bookings[$booked]['checkin']}
Checkout date: {$availabilitycalendar->bookings[$booked]['checkout']}
Price: {$availabilitycalendar->bookings[$booked]['price']}
Comments: {$availabilitycalendar->bookings[$booked]['comments']}' href='managebookings.php?cmd=LoginDisplayBooking&bookingid=$booked'>$day</a>";

} else {
$html_out .= "<span class=\"booked\">$day</span>";
}
			}


			if ($dw > 7) {
				$html_out .= '<br />';
				$dw = 1;
			}
		}
		$html_out .= '</div>';
	}

	print $html_out;

print "</div>";
?>