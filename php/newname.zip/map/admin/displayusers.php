<?php

	print "<h2>Users</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";

	print "<tr>";
	print "<th>Action</th>";	
	print "<th>UserID</th>";
	print "<th>Email</th>";
	print "<th>Password</th>";
	print "<th>Username</th>";
	print "<th>Property Allocation</th>";
	print "<th>Type</th>";
	print "<th>Status</th>";
	print "<th>Last Logon</th>";
	print "<th>Comments</th>";
	print "</tr>";

	if (isset($users)) {

	$counter = 0;
	foreach ($users as &$value) {

		print "<tr>";

		print "<td>";
		//print "<form method='POST'><button type='submit' class='btn btn-sm btn-success btn-block'>edit</button><input type='hidden' name='userid' value='".$users[$counter]['userid']."'><input type='hidden' name='cmd' value='AdminUpdateUser'></form>";
		//print "<form method='POST'><button type='submit' class='btn btn-sm btn-danger btn-block'>delete</button><input type='hidden' name='userid' value='".$users[$counter]['userid']."'><input type='hidden' name='cmd' value='AdminDeleteUser'></form>";
		print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><a href='/admin/users/?cmd=LoginAdminUpdateUser&userid=".$users[$counter]['userid']."'><button type='button' class='btn btn-sm btn-success btn-block'>edit</button></a></div>";
		print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><a href='/admin/users/?cmd=LoginAdminDeleteUser&userid=".$users[$counter]['userid']."'><button type='button' class='btn btn-sm btn-danger btn-block'>delete</button></a></div>";
		print "</td>";

		print "<td>".$users[$counter]['userid']."</td>";
		print "<td>".$users[$counter]['email']."</td>";
		print "<td>".$users[$counter]['password']."</td>";
		print "<td>".$users[$counter]['username']."</td>";
		print "<td>".$users[$counter]['propertyallocation']."</td>";
		print "<td>".$users[$counter]['type']."</td>";
		print "<td>".$users[$counter]['status']."</td>";
		print "<td>".$users[$counter]['lastlogon']."</td>";
		print "<td>".$users[$counter]['comments']."</td>";
		print "</tr>";
		print "<tr>";
		//print "<tr>";
		//print "<td colspan='15'><strong>Comments:</strong> ".$users[$counter]['comments']."</td>";
		//print "</tr>";

		$counter = $counter + 1;
	}

	unset($value); // break the reference with the last element

	}


	print "</table></div>";

?>