<?php

	$enquirydetail = $enquiry->getEnquiryDetail();

	print "<h2>Enquiry Detail</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";
	print "<tr><th style='text-align:center' colspan='2'>Customer Info</th></tr>";
	print "<tr><td>EnquiryPostID</td><td>".$enquirydetail['enquirypostid']."</td></tr>";
	print "<tr><td>Customer Name</td><td>".$enquirydetail['customername']."</td></tr>";
	print "<tr><td>Customer Email</td><td>".$enquirydetail['customeremail']."</td></tr>";
	print "<tr><td>Phone</td><td>".$enquirydetail['phone']."</td></tr>";
	print "<tr><td>Country</td><td>".$enquirydetail['country']."</td></tr>";
	print "<tr><td>Adults</td><td>".$enquirydetail['adults']."</td></tr>";
	print "<tr><td>Kids</td><td>".$enquirydetail['kids']."</td></tr>";
	print "<tr><td>Checkin</td><td>".$enquirydetail['checkin']."</td></tr>";
	print "<tr><td>Checkout</td><td>".$enquirydetail['checkout']."</td></tr>";
	print "<tr><td>Flexible</td><td>".$enquirydetail['flexible']."</td></tr>";
	print "<tr><td>Currency</td><td>".$enquirydetail['currency']."</td></tr>";
	print "<tr><td>Comments</td><td>".$enquirydetail['comments']."</td></tr>";
	print "<tr><td>Criteria</td><td>".$enquirydetail['criteria']."</td></tr>";
	print "<tr><td>Posted</td><td>".$enquirydetail['posted']."</td></tr>";
	print "<tr><td>IP Address</td><td>".$enquirydetail['ipaddress']."</td></tr>";
	print "<tr><td>Status</td><td>".$enquirydetail['status']."</td></tr>";
	print "<tr><th style='text-align:center' colspan='2'>Recipient Info</th></tr>";
	print "<tr><td>Propertyid</td><td>".$enquirydetail['propertyid']."</td></tr>";
	print "<tr><td>Owner Name</td><td>".$enquirydetail['ownername']."</td></tr>";
	print "<tr><td>Owner Email</td><td>".$enquirydetail['owneremail']."</td></tr>";
	print "</table></div>";

?>