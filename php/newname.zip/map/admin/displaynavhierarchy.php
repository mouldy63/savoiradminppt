<?php

print "<h2>display nav hierarchy</h2>";

foreach($nav as $nav_item){
    //skip lower level links
    if($nav_item['level'] > 1){
        continue;
    }
    //display current link ?>
<div class="well well-sm" style="max-width:350px;margin-bottom: 0.5em;" title="<?php echo $nav_item['link']; ?>">
    <?php echo $nav_item['display']." ".$nav_item['icon']." (".$nav_item['sortorder'].")";  
    $add_details = "navid=".$nav_item['navid']."&lvl=1&sortorder=".$nav_item['sortorder'];
    ?> 
    <div class="btn-group btn-group-xs pull-right">
        <a href="/navigation/?cmd=LoginAdminLeftIndentNav&<?php echo $add_details;?>" class="btn btn-primary" title="left indent"><span class="glyphicon glyphicon-circle-arrow-left"></span></a>
        <a href="/navigation/?cmd=LoginAdminMoveUpNav&<?php echo $add_details;?>" class="btn btn-primary" title="move up"><span class="glyphicon glyphicon-circle-arrow-up"></span></a>
        <a href="/navigation/?cmd=LoginAdminMoveDownNav&<?php echo $add_details;?>" class="btn btn-primary" title="move down"><span class="glyphicon glyphicon-circle-arrow-down"></span></a>
        <a href="/navigation/?cmd=LoginAdminRightIndentNav&<?php echo $add_details;?>" class="btn btn-primary" title="right indent"><span class="glyphicon glyphicon-circle-arrow-right"></span></a>
        <a href="/navigation/?cmd=LoginAdminUpdateNav&navid=<?php echo $nav_item['navid'];?>" class="btn btn-info" title="Update Nav"><span class="glyphicon glyphicon-edit"></span></a>
        <a href="/navigation/?cmd=LoginAdminDeleteNav&navid=<?php echo $nav_item['navid'];?>" class="btn btn-danger" title="Delete Nav"><span class="glyphicon glyphicon-trash"></span></a>
    </div>
</div>
<?php    
    
    display_nav_level($nav, $nav_item['navid'], 2 );
} //end foreach nav

function display_nav_level($nav_array, $parent_id, $level, $margin_left = 2){
    static $fail_safe = 0;
    
    /***in case of an error, this will prevent infite looping ***/
    if( $fail_safe++ > 1000 ){
        return;
    }
    /***  ***/
    
    //display child links 
    foreach($nav_array as $cur_level){
        if($cur_level['parent_id'] == $parent_id && $cur_level['level'] == $level){
?>
<div class="well well-sm" style="max-width:350px;margin-left:<?php echo $margin_left; ?>em;margin-bottom: 0.5em;" title="<?php echo $cur_level['link']; ?>">
    <?php echo $cur_level['display']." ".$cur_level['icon']." (".$cur_level['sortorder'].")";  
    $add_details = "navid=".$cur_level['navid']."&lvl=$level&ptid=".$cur_level['parent_id']."&sortorder=".$cur_level['sortorder'];
    ?> 
    <div class="btn-group btn-group-xs pull-right">
        <a href="/navigation/?cmd=LoginAdminLeftIndentNav&<?php echo $add_details;?>" class="btn btn-primary" title="left indent"><span class="glyphicon glyphicon-circle-arrow-left"></span></a>
        <a href="/navigation/?cmd=LoginAdminMoveUpNav&<?php echo $add_details;?>" class="btn btn-primary" title="move up"><span class="glyphicon glyphicon-circle-arrow-up"></span></a>
        <a href="/navigation/?cmd=LoginAdminMoveDownNav&<?php echo $add_details;?>" class="btn btn-primary" title="move down"><span class="glyphicon glyphicon-circle-arrow-down"></span></a>
        <a href="/navigation/?cmd=LoginAdminRightIndentNav&<?php echo $add_details;?>" class="btn btn-primary" title="right indent"><span class="glyphicon glyphicon-circle-arrow-right"></span></a>
        <a href="/navigation/?cmd=LoginAdminUpdateNav&navid=<?php echo $cur_level['navid'];?>" class="btn btn-info" title="Update Nav"><span class="glyphicon glyphicon-edit"></span></a>
        <a href="/navigation/?cmd=LoginAdminDeleteNav&navid=<?php echo $cur_level['navid'];?>" class="btn btn-danger" title="Delete Nav"><span class="glyphicon glyphicon-trash"></span></a>
    </div>
</div>
<?php  
            //display children
            display_nav_level($nav_array, $cur_level['navid'], $level+1, $margin_left + 2);
            
        }//end if
    }//end foreach nav
    return;
}//end function