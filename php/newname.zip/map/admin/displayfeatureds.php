<?php

	print "<h2>Featured Properties</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";

	print "<tr>";
	print "<th>Action</th>";	
	print "<th>PropertyID</th>";
	print "<th>Featured</th>";
	print "</tr>";

	if (isset($featureds)) {

	$counter = 0;
	foreach ($featureds as &$value) {

		print "<tr>";

		print "<td>";
		if ($featureds[$counter]['featured'] == null) {
			print "<form method='POST'><button type='submit' class='btn btn-sm btn-success btn-block'>feature</button><input type='hidden' name='propertyid' value='".$featureds[$counter]['propertyid']."'><input type='hidden' name='cmd' value='LoginAdminAddFeatured'></form>";
		} else {
			print "<form method='POST'><button type='submit' class='btn btn-sm btn-danger btn-block'>remove</button><input type='hidden' name='propertyid' value='".$featureds[$counter]['propertyid']."'><input type='hidden' name='cmd' value='LoginAdminDeleteFeatured'></form>";
		}
		print "</td>";

		print "<td>".$featureds[$counter]['propertyid']."</td>";

		if ($featureds[$counter]['featured'] == null) {
			print "<td></td>";
		} else {
			print "<td>Featured</td>";
		}

		print "</tr>";

		$counter = $counter + 1;
	}

	unset($value); // break the reference with the last element

	}

	print "</table></div>";

?>