<?php
//die( /*var_dump($view->returnEnquiryCriteria())*/ );
	print "<h2>Configuration Settings</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";
	print "<tr><th>Setting</th><th>Value(s)</th></tr>";
	print "<tr><td>Base User Context</td><td>".$view->getBaseUserContext()."</td></tr>";
	
        $prop_tt = "";
        foreach( $view->returnPropertyTypes() as $k => $v ){
            $prop_tt .= $v['key'][0] ." = ".$v['terminology'][0] . "<br>";
        } 
        print "<tr><td>Property Types and Terminology</td><td>$prop_tt</td></tr>";
        print "<tr><td>Property Type Enquiry Criteria</td><td>".implode(", ", $view->returnEnquiryCriteria())."</td></tr>";
        
	print "<tr><td>Website Name (for email templates)</td><td>".$view->getResort()."</td></tr>";
	print "<tr><td>Email Address (for email templates)</td><td>".$view->getResortEmail()."</td></tr>";
	print "<tr><td>Website Domain (for email templates)</td><td>".$view->getResortWebsite()."</td></tr>";
	print "<tr><td>Facebook Page Unique Key</td><td>".$view->getResortFacebook()."</td></tr>";
	print "<tr><td>Twitter Page Unique Key</td><td>".$view->getResortTwitter()."</td></tr>";
	print "<tr><td>Google+ Page Unique Key</td><td>".$view->getResortGoogle()."</td></tr>";
	print "<tr><td>Pinterest Page Unique Key</td><td>".$view->getResortPinterest()."</td></tr>";
	print "<tr><td>Instagram Page Unique Key</td><td>".$view->getResortInstagram()."</td></tr>";
	print "<tr><td>Owner Websites Permissable</td><td>".$view->getOwnerWebsites("TEXT")."</td></tr>";
	//print "<tr><td>Location Hierarchy</td><td>";
	//if ($view->getLocationHierarchy()) {print "True";} else {print "False";}
	//print "</td></tr>";
	//if ($view->getLocationHierarchy()) {
	//	print "<tr><td colspan='2'>";
	//	print_r($locations);
	//	print "</td></tr>";
	//}
	print "</table></div>";
        
        $prop_details = $prop_features = [];
        $view->getPropertySettings($prop_details, $prop_features);
        
        print "<h3>Property Details</h3>";
        print "<div class='table-responsive'><table class='table table-striped'>";
	print "<tr><th>Field Name</th><th>Label</th></tr>";
        foreach( $prop_details as $k => $v ){
            print "<tr><td>".$k."</td><td>".$v."</td></tr>";
        }
        print "</table></div>";

        print "<h3>Property Features</h3>";
        print "<div class='table-responsive'><table class='table table-striped'>";
	print "<tr><th>Field Name</th><th>Label</th></tr>";
        foreach( $prop_features as $k => $v ){
            print "<tr><td>".$k."</td><td>".$v."</td></tr>";
        }
        print "</table></div>";
?>