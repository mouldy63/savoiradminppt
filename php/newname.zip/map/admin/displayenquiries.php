<?php

	$enquirysummary = $enquiries->getEnquirySummary();

	print "<h2>Enquiries</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";

	print "<tr>";
	print "<th>Action</th>";	
	print "<th>EnquiryPostID</th>";
	print "<th>Customer Name</th>";
	print "<th>Customer Email</th>";
	print "<th>PropertyID</th>";
	print "<th>Owner Name</th>";
	print "<th>Owner Email</th>";
	print "<th>Posted</th>";
	print "<th>Status</th>";
	print "</tr>";

	$counter = 0;
	foreach ($enquirysummary as &$value) {

		print "<tr>";

		print "<td>";
		
		if ($enquirysummary[$counter]['status'] == 'C') {
			print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-warning  btn-block'>release</button><input type='hidden' name='enquirypostid' value='".$enquirysummary[$counter]['enquirypostid']."'><input type='hidden' name='cmd' value='AdminUpdateEnquiry'><input type='hidden' name='enquirypostid' value='".$enquirysummary[$counter]['enquirypostid']."'></form></div>";
		} else {
			print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-success  btn-block'>re-send</button><input type='hidden' name='enquirypostid' value='".$enquirysummary[$counter]['enquirypostid']."'><input type='hidden' name='cmd' value='AdminUpdateEnquiry'><input type='hidden' name='enquirypostid' value='".$enquirysummary[$counter]['enquirypostid']."'></form></div>";
		}

		print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><a href='/admin/enquiries/?cmd=LoginAdminDisplayEnquiry&enquirypostid=".$enquirysummary[$counter]['enquirypostid']."'><button type='button' class='btn btn-sm btn-primary btn-block'>display</button></a></form></div>";

		//print "<a href='/admin/properties/?cmd=LoginAdminUpdateProperty&propertyid=".$properties[$counter]['propertyid']."'><button type='button' class='btn btn-sm btn-success btn-block'>edit</button></a>";
		print "</td>";

		print "<td>".$enquirysummary[$counter]['enquirypostid']."</td>";
		print "<td>".$enquirysummary[$counter]['customername']."</td>";
		print "<td>".$enquirysummary[$counter]['customeremail']."</td>";
		print "<td>".$enquirysummary[$counter]['propertyid']."</td>";
		print "<td>".$enquirysummary[$counter]['ownername']."</td>";
		print "<td>".$enquirysummary[$counter]['owneremail']."</td>";
		print "<td>".$enquirysummary[$counter]['posted']."</td>";
		print "<td>".$enquirysummary[$counter]['status']."</td>";
		print "</tr>";

		$counter = $counter + 1;
	}

	unset($value); // break the reference with the last element

	print "</table></div>";

?>