<?php

	print "<h2>Properties</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";

	print "<tr>";
	print "<th>Action</th>";	
	print "<th>PropertyID</th>";
	print "<th>Property Name</th>";
	print "<th>Owner</th>";
	print "<th>UserID</th>";
	print "<th>Username</th>";
	print "<th>Type</th>";
	print "<th>Currency</th>";
	//print "<th>External Calendar</th>";
	print "<th>LocationID</th>";
	print "<th>Enquiry Preference</th>";
	print "<th>Status</th>";
	print "<th>Expiry Date</th>";
	print "<th>Last Updated</th>";
	print "<th>Calendar Last Updated</th>";

	print "</tr>";

	if (isset($properties)) {

	$counter = 0;
	foreach ($properties as &$value) {

		print "<tr>";

		print "<td>";
		
		if ($properties[$counter]['status'] == 'B') {
			print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-primary  btn-block'>subscribe</button><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'><input type='hidden' name='cmd' value='AdminSubscribeProperty'><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'></form></div>";
		} else {
			print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-danger  btn-block'>un-subscribe</button><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'><input type='hidden' name='cmd' value='AdminUnsubscribeProperty'><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'></form></div>";
		}

		print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><a href='/admin/properties/?cmd=LoginAdminUpdateProperty&propertyid=".$properties[$counter]['propertyid']."'><button type='button' class='btn btn-sm btn-success btn-block'>edit</button></a></form></div>";

		//print "<a href='/admin/properties/?cmd=LoginAdminUpdateProperty&propertyid=".$properties[$counter]['propertyid']."'><button type='button' class='btn btn-sm btn-success btn-block'>edit</button></a>";
		print "</td>";

		print "<td>".$properties[$counter]['propertyid']."</td>";
		print "<td>".$properties[$counter]['name']."</td>";
		print "<td>".$properties[$counter]['owner']."</td>";
		print "<td>".$properties[$counter]['userid']."</td>";
		print "<td>".$properties[$counter]['username']."</td>";
		print "<td>".$properties[$counter]['type']."</td>";
		print "<td>".$properties[$counter]['basecurrency']."</td>";
		//print "<td>".$properties[$counter]['externalcalendar']."</td>";
		print "<td>".$properties[$counter]['locID']."</td>";
		print "<td>".$properties[$counter]['enquirypreference']."</td>";
		print "<td>".$properties[$counter]['status']."</td>";
		print "<td>".$properties[$counter]['subscriptionexpiry']."</td>";
		print "<td>".$properties[$counter]['updated']."</td>";
		print "<td>".$properties[$counter]['calendarupdated']."</td>";
		print "</tr>";
		print "<tr>";

		$counter = $counter + 1;
	}

	unset($value); // break the reference with the last element

	}

	print "</table></div>";

?>