<?php

	print "<h2>Content Management System</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";

	print "<tr>";
	print "<th>Action</th>";	
	print "<th>PageID</th>";
	print "<th>Page Type</th>";
	print "<th>Folder Location</th>";
	print "<th>Content Type</th>";
	print "<th>Last Updated</th>";

	print "</tr>";

	$counter = 0;
	foreach ($content as &$value) {

		print "<tr>";

		print "<td>";
		
		//if ($properties[$counter]['status'] == 'B') {
		//	print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-primary  btn-block'>subscribe</button><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'><input type='hidden' name='cmd' value='AdminSubscribeProperty'><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'></form></div>";
		//} else {
		//	print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-danger  btn-block'>un-subscribe</button><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'><input type='hidden' name='cmd' value='AdminUnsubscribeProperty'><input type='hidden' name='propertyid' value='".$properties[$counter]['propertyid']."'></form></div>";
		//}

		if ($content[$counter]['contenttype'] == 'P') {
			print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><a href='/admin/content/?cmd=LoginAdminUpdatePage&pageid=".$content[$counter]['pageid']."'><button type='button' class='btn btn-sm btn-success btn-block'>update page</button></a></form></div>";
		} else {
			print "<div class='col-md-12' style='padding:2px;margin-bottom: 6px;'><a href='/admin/content/?cmd=LoginAdminUpdateContent&contentid=".$content[$counter]['contentid']."'><button type='button' class='btn btn-sm btn-success btn-block'>update content</button></a></form></div>";
		}

		//print "<a href='/admin/properties/?cmd=LoginAdminUpdateProperty&propertyid=".$properties[$counter]['propertyid']."'><button type='button' class='btn btn-sm btn-success btn-block'>edit</button></a>";
		print "</td>";

		print "<td>".$content[$counter]['pageid']."</td>";
		print "<td>".$view->formatPageType($content[$counter]['pagetype'])."</td>";
		print "<td>".$content[$counter]['folderlocation']."</td>";
		print "<td>".$view->formatContentType($content[$counter]['contenttype'])."</td>";
		print "<td>".$content[$counter]['lastupdate']."</td>";
		print "</tr>";
		print "<tr>";

		$counter = $counter + 1;
	}

	unset($value); // break the reference with the last element

	print "</table></div>";

?>