<?php

	print "<h2>Subscriptions</h2>";

	print "<div class='table-responsive'><table class='table table-striped'>";

	print "<tr>";
	print "<th>Property ID</th>";	
	print "<th>Property Name</th>";
	print "<th>Expiry Date</th>";
	print "<th>User Name</th>";
	print "<th>Subscriber Email</th>";
	print "<th>Subscriber Location</th>";
	print "</tr>";

	if (isset($subscriptions)) {

	$counter = 0;
	foreach ($subscriptions as &$value) {

		print "<tr>";
		print "<td>".$subscriptions[$counter]['propertyid']."</td>";
		print "<td>".$subscriptions[$counter]['name']."</td>";
		print "<td>".$subscriptions[$counter]['subscriptionexpiry']."</td>";
		print "<td>".$subscriptions[$counter]['username']."</td>";
		print "<td>".$subscriptions[$counter]['email']."</td>";
		print "<td>".$subscriptions[$counter]['location']."</td>";
		print "</tr>";
		print "<tr>";

		$counter = $counter + 1;
	}

	unset($value); // break the reference with the last element

	}


	print "</table></div>";

?>