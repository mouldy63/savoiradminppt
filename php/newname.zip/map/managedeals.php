<?php

$counter = 0;

print "<h2>Manage Deals</h2>";

if ($posted[$counter] > 14) {print "<div class='alert alert-warning' role='alert'>Your current deal is now expired as 2 weeks have elapsed since posting.  To re-display to holidaymakers we require you to update.</div>";}

foreach ($leadimage as &$value) {

	print "<div class='col-sm-4' ><img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/thumb.php?src=".$leadimage[$counter]."&size=600x450&trim=1&zoom=1' alt='".$image_alt[$counter]."' class='img-responsive' style='margin-top:0px;'></div>";


	print"<div class='col-sm-8' >";
	print "<h3 class='text-left'>Deal ".$dealids[$counter]." - ".$banner[$counter]."</h3>";
	print "<p>".$detail[$counter]."</p>";
	if (isset($checkin[$counter])) {
		print "<p>Date Range: ".$checkin[$counter]." - ".$checkout[$counter]."</p>";
	}
	if (isset($currency[$counter])) {
		print "<p>Price Per Night (inc. Tax): <strong>".$view->formatCurrency($currency[$counter]).$price[$counter]."</strong></p>";
	}

	print "</div>";
	print "<div style='border-bottom: 2px solid #4DBDEB;clear:both;margin:10px 14px 20px 14px;'></div></div>";

	$counter = $counter +1;
}

unset($value); // break the reference with the last element

?>