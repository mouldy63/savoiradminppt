<?php

//$mode settings
//0 = display
//1 = success message
//2 = fail message
if (!(isset($mode))) {$mode = 0;}





print "<div class='form-group'>";

print "<h3>Manage Pictures (images remaining: <u>";
print 24 - $pictures->imageCount();
print "</u>)</h3>";

if ($mode == 1) {
	print "<div class='alert alert-success' role='alert'>".$view->getFeedback()."</div>";
} elseif ($mode == 2) {
		print "<div class='alert alert-danger' role='alert'><span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span><span class='sr-only'>Error:</span> ".$view->getFeedback()."</div>";
}

$imageid_array = $pictures->getImageidArray();
$image_array = $pictures->getImageArray();
$image_alt_array = $pictures->getAltArray();
$image_lead_array = $pictures->getLeadArray();
$image_width_array = $pictures->getThumbnailWidthArray();
$image_height_array = $pictures->getThumbnailHeightArray();
$image_position_array = $pictures->getPositionArray();

$imagecount = count($imageid_array);

print "<div class='row'>";
	
$counter = 0;

while ($counter <= $imagecount-1) {

	//open div segment
	print "<div class='col-sm-6 col-md-4'><div class='thumbnail mpbox' >";

	//display image
	print "<img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/thumb.php?src=".$image_array[$counter]."&size=600x450&trim=1&zoom=1' alt='".$image_alt_array[$counter]."'>";

	//open caption div
	print "<div class='caption' style='height: 160px;'>";

	//caption header
	$imagenumber = $counter + 1;
	print "<h3 class='text-center'>Image ".$imagenumber."</h3>";

	//image text
	print "<p class='text-center' id='d".$counter."'>".$image_alt_array[$counter]."&nbsp;<i class='fa fa-pencil-square-o'  onClick='hided".$counter."()'></i></p>";
	print "<form method='POST' action='/managepictures.php'><input type='hidden' name='imageid' value='".$imageid_array[$counter]."'><input type='hidden' name='cmd' value='LoginUpdatePictureText'>";
print "<input type='text' name='alt' id='e".$counter."' size='20' maxlength='50' value='".$image_alt_array[$counter]."' class='form-control' style='display:none;margin-top: 23px;    margin-bottom: 22px;'>";
print "</form>";



print "<script>function hided".$counter."() {    var el = document.getElementById('d".$counter."');        el.style.display = 'none';var el2 = document.getElementById('e".$counter."');        el2.style.display = 'block';}</script>";
	
	print "<div class='col-md-6' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-success btn-block'><i class='";

	if ($image_lead_array[$counter] == 'Y') {
		print "fa fa-check-square-o'></i> LEAD PIC";
	} else {
		print "fa fa-check-o'></i> SET LEAD";
	}

	print "</button><input type='hidden' name='lead' value='".$imageid_array[$counter]."'><input type='hidden' name='cmd' value='LoginUpdateLeadPicture'></form></div>";
	print "<div class='col-md-6' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-danger btn-block'>DELETE</button><input type='hidden' name='imageid' value='".$imageid_array[$counter]."'><input type='hidden' name='cmd' value='LoginDeletePicture'></form></div>";

	if ($imagecount > 1) { //dont show move up or down buttons if only 1 image

		if ($counter == 0) { //if first image set moveup button to move image to last position
			$newpositionup = $imagecount;
			$newpositiondown = $image_position_array[$counter] + 1;
		} elseif (($counter + 1) == $imagecount) { //if last image set move down button to move to first position (require to add one to counter for calculation as counter starts at zero not 1)
			$newpositionup = $image_position_array[$counter] - 1;
			$newpositiondown = 1;
		} else {
			$newpositionup = $image_position_array[$counter] - 1;
			$newpositiondown = $image_position_array[$counter] + 1;
		}

		print "<div class='col-md-6' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-info  btn-block'><i class='fa fa-arrow-up'></i> MOVE UP</button><input type='hidden' name='imageid' value='".$imageid_array[$counter]."'><input type='hidden' name='cmd' value='LoginReOrderPicture'><input type='hidden' name='newposition' value='".$newpositionup."'></form></div><div class='col-md-6' style='padding:2px;margin-bottom: 6px;'><form method='POST'><button type='submit' class='btn btn-sm btn-info  btn-block'><i class='fa fa-arrow-down'></i> MOVE DOWN</button><input type='hidden' name='imageid' value='".$imageid_array[$counter]."'><input type='hidden' name='cmd' value='LoginReOrderPicture'><input type='hidden' name='newposition' value='".$newpositiondown."'></form></div>";

	}
	
	//open caption div
	print "</div>";

	//close div segment
	print "</div></div>";

	$counter = $counter+1;

}

print "</div>";


?>