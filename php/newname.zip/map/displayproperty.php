<?php

print "<div id='pictures'>";
print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";

//if property already enquired about flag this
if ((isset($prevenquiry)) && (in_array ($propertydetails->getPropertyid(),$prevenquiry['recipientlist']))) {
	print "<h1 class='propertyheaders'>".$propertydetails->getBanner()." <span class='label label-success'>Enquiry Sent</span></h1>";
} else {
	print "<h1 class='propertyheaders'>".$propertydetails->getBanner()."</h1>";
}

$image_lead = $propertydetails->getImageLead();
$alt_lead = $propertydetails->getAltLead();
$image_array = $propertydetails->getImage();
$image_alt_array = $propertydetails->getAlt();
$image_lead_array = $propertydetails->getLead();
$image_width_array = $propertydetails->getThumbnailWidth();
$image_height_array = $propertydetails->getThumbnailHeight();

//display lead image as main image first
print "<div class='propertywrapper'><div id='sync1' class='owl-carousel' class='margint15'>";
print "<div class='textc'><img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$image_lead."'  alt='".$alt_lead."' style='max-height:300px;'/><div class='slidertext'>".$alt_lead."</div></div>";

$counter = 0;

foreach ($image_array as &$value) {

	//build javascript for switching lead image on click
	$image = "/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$value;
	$image_change_javascript = "document.images.lead.src='$image'";

	if ($image_lead<>$value) {
	
	print "<div class='textc'><img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$value."'  alt='".$image_alt_array[$counter]."'  style='max-height:300px;'/><div class='slidertext'>".$image_alt_array[$counter]."</div></div>";	
	
	}

	$counter = $counter + 1;
	
}

print "</div>";

$marginleftpadding=0;


if ($counter<=3 && $counter>0) {
print "<div align='center' style='margin-bottom:20px;'>";
$counter2=0;
foreach ($image_array as &$value) {
$counter2=$counter2+1;
	//build javascript for switching lead image on click
	$image = "/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$value;
	$image_change_javascript = "document.images.lead.src='$image'";
	
	print "<div class='nailthumb-container square' style='display: inline-block; margin:0 20px 0 20px;'><img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$value."'   class='item".$counter2."'/></div>";

	
	
	
}
print "</div>";
}

if ($counter==0) {
print "<BR><BR>";
}

print "<div id='sync2' class='owl-carousel'>";
if ($counter>3) {


list($width, $height) = getimagesize($view->getDocumentRoot()."/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$image_lead);
if ($width > $height) {
    $ccc="";
} else {
    $ccc="portrait";
}

print "<div class='item'><img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/thumb.php?src=".$image_lead."&size=135x101&trim=1&zoom=1 class='".$ccc."'/></div>";

foreach ($image_array as &$value) {

	//build javascript for switching lead image on click
	$image = "/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$value;
	$image_change_javascript = "document.images.lead.src='$image'";

	if ($image_lead<>$value) {
	
	list($width, $height) = getimagesize($view->getDocumentRoot()."/websites/".strtolower($view->getWebsiteFolder())."/data/images/".$value);
if ($width > $height) {
    $ccc="";
	$sss="style='top:20px;'";
} else {
    $ccc="portrait";
	$sss="style='top:20px;'";
}


	
	print "<div class='item'><img src='/websites/".strtolower($view->getWebsiteFolder())."/data/images/thumb.php?src=".$value."&size=135x101&trim=1&zoom=1 class='".$ccc."'/></div>";

	$counter = $counter + 1;	
	
	}
}

}
print "</div>";
unset($value); // break the reference with the last element


//close off thumnbail div
print "</div></div>";

print "</div></div>";

if (count($ratebands->getRateidArray()) > 0) {
//if rates added get lowest and highest rate for display and cater for base currency and currency preference conversions
switch ($ratesinfo->getBasecurrency()) {
	case 'S':
		switch ($view->getUserContext()) {
		case 'UK':
			$ratesfrom = $view->formatCurrency($ratesinfo->getBasecurrency()).number_format($ratebands->getRatesFrom());
			$ratesto = $view->formatCurrency($ratesinfo->getBasecurrency()).number_format($ratebands->getRatesTo());
			break;
		case 'US':
			$ratesfrom = $view->formatCurrency('D').number_format($ratebands->getRatesFrom() * $exchangerates->getGBPUSD());
			$ratesto = $view->formatCurrency('D').number_format($ratebands->getRatesTo() * $exchangerates->getGBPUSD());
			break;
		case 'EU':
			$ratesfrom = $view->formatCurrency('E').number_format($ratebands->getRatesFrom() * $exchangerates->getGBPEUR());
			$ratesto = $view->formatCurrency('E').number_format($ratebands->getRatesTo() * $exchangerates->getGBPEUR());
			break;
		}
		break;
	Case 'D':
		switch ($view->getUserContext()) {
		case 'UK':
			$ratesfrom = $view->formatCurrency('S').number_format($ratebands->getRatesFrom() * $exchangerates->getUSDGBP());
			$ratesto = $view->formatCurrency('S').number_format($ratebands->getRatesTo() * $exchangerates->getUSDGBP());
			break;
		case 'US':
			$ratesfrom = $view->formatCurrency($ratesinfo->getBasecurrency()).number_format($ratebands->getRatesFrom());
			$ratesto = $view->formatCurrency($ratesinfo->getBasecurrency()).number_format($ratebands->getRatesTo());
			break;
		case 'EU':
			$ratesfrom = $view->formatCurrency('E').number_format($ratebands->getRatesFrom() * $exchangerates->getUSDEUR());
			$ratesto = $view->formatCurrency('E').number_format($ratebands->getRatesTo() * $exchangerates->getUSDEUR());
			break;
		}
		break;
	case 'E':
		switch ($view->getUserContext()) {
		case 'UK':
			$ratesfrom = $view->formatCurrency('S').number_format($ratebands->getRatesFrom() * $exchangerates->getEURGBP());
			$ratesto = $view->formatCurrency('S').number_format($ratebands->getRatesTo() * $exchangerates->getEURGBP());
			break;
		case 'US':
			$ratesfrom = $view->formatCurrency('D').number_format($ratebands->getRatesFrom() * $exchangerates->getEURUSD());
			$ratesto = $view->formatCurrency('D').number_format($ratebands->getRatesTo() * $exchangerates->getEURUSD());
			break;
		case 'EU':
			$ratesfrom = $view->formatCurrency($ratesinfo->getBasecurrency()).number_format($ratebands->getRatesFrom());
			$ratesto = $view->formatCurrency($ratesinfo->getBasecurrency()).number_format($ratebands->getRatesTo());
			break;
		}
		break;
}
}


print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";

print "<p><span class='label label-primary'>".$view->formatType($propertydetails->getType())."</span> <span class='label label-primary'>Sleeps ".$propertydetails->getOccupancy()."</span> <span class='label label-primary'>".$propertydetails->getBedrooms()." Bedrooms</span>";
if ($propertydetails->getBathrooms()) { print " <span class='label label-primary'>".$propertydetails->getBathrooms()." Bathrooms</span></p>";
} else {print "</p>";}

//print "<h2 style='font-size:20px;border-bottom: 2px solid #4DBDEB;'>Property Name: ".$propertydetails->getName()."</h2>";
print "<h2 style='font-size:20px;border-bottom: 2px solid #4DBDEB;'>".$propertydetails->getName()."</h2>";

if (count($ratebands->getRateidArray()) > 0) {
print "<h2 class='orange'><small><span class='orange'>FROM</span></small> ".$ratesfrom." <small><span class='orange'>TO</span></small> ".$ratesto." <small><span class='orange'>P/W</span></small></h2>";
}
print "</p>";

print "<p><a href='#contactowner'><button type='button' class='btn btn-primary'>Enquire Now</button></a></p>";

print "<h2>Property Features</h2>";

print "<ul class='collist'>";

//output all selected features
foreach( $propertydetails->getFeatures() as $k => $v ){
    if( $v[1]== "Y" ) {print "<li><i class='fa fa-check-square-o'></i> ".$v[0]."</li> ";}
}

print "</ul>";

if ($propertydetails->getFloorspace()) {print "<p>Floorspace: <strong>".$propertydetails->getFloorspace()." sq ft</strong></p>";}

print "<h2>Bed Detail</h2>";

print "<p>";

$counter=0;
if ($propertydetails->getKingbeds() > 0) {
	print "<span class='label label-default'>".$propertydetails->getKingbeds()." King</span>";
	$counter=$counter+1;
}

if ($propertydetails->getQueenbeds() > 0) {
	if ($counter > 0) {
		print " <span class='label label-default'>".$propertydetails->getQueenbeds()." Queen</span>";
	} else {
		print "<span class='label label-default'>".$propertydetails->getQueenbeds()." Queen</span>";
	}
	$counter=$counter+1;
}

if ($propertydetails->getTwinbeds() > 0) {
	if ($counter > 0) {
		print " <span class='label label-default'>".$propertydetails->getTwinbeds()." Twin</span>";
	} else {
		print "<span class='label label-default'>".$propertydetails->getTwinbeds()." Twin</span>";
	}
	$counter=$counter+1;
}

if ($propertydetails->getDoublebeds() > 0) {
	if ($counter > 0) {
		print " <span class='label label-default'>".$propertydetails->getDoublebeds()." Double</span>";
	} else {
		print "<span class='label label-default'>".$propertydetails->getDoublebeds()." Double</span>";
	}
	$counter=$counter+1;
}

if ($propertydetails->getSofabeds() > 0) {
	if ($counter > 0) {
		print " <span class='label label-default'>".$propertydetails->getSofabeds()." Sofa</span>";
	} else {
		print "<span class='label label-default'>".$propertydetails->getSofabeds()." Sofa</span>";
	}
	$counter=$counter+1;
}

print "</p>";

print "</div></div>";

//output the details 1 only; $k is the dbs fieldname (e.g. details1)
$details_count = 0;
foreach( $propertydetails->getDetails() as $k => $v ){
    print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";
    print "<h2>".$v[0]."</h2>"; //label
    print "<p>".nl2br($v[1])."</p>"; //value
    print "<hr>";
    print "</div></div>";
    if ( ++$details_count > 0 ){
        break;
    }
}

print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";
print "<h2>Rates</h2>";
//display rates params
$ratestype=1; // 0 = internal, 1 = external
//get rates table if rates added else display old rates text
if (count($ratebands->getRateidArray()) > 0) {
require_once('displayrates.php');
} else {
print "<p></p>";
}
print "<hr>";
print "</div></div>";

print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";
print "<h2>Location</h2>";
print "<p>".$propertydetails->getLocation()."</p>";
print "<hr>";
print "</div></div>";

/*************/
//output the details 2 and up; $k is the dbs fieldname (e.g. details1)
$details_count = 0;
foreach( $propertydetails->getDetails() as $k => $v ){
    if ( $details_count++ == 0 ){
        continue;
    }
    print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";
    print "<h2>".$v[0]."</h2>"; //label
    print "<p>".nl2br($v[1])."</p>"; //value
    print "<hr>";
    print "</div></div>";
}

// only add Virtual Tour iframe if virtual tour attached to property
if ($propertydetails->getVirtualtourid()) {
	print "<div class='row'><div class='col-sm-12 about-us-text wow fadeInLeft'>";
	print "<h2>Virtual Tour</h2>";
	print $view->virtualTourFormat($propertydetails->getVirtualtoursource(),$propertydetails->getVirtualtourid());
	print "</div></div>";
}

?>